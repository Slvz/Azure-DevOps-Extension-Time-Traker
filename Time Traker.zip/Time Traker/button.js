// Get the button that opens the modal
let btn = document.getElementById("myBtn");
let _date = document.getElementById("date");
let _time = document.getElementById("time");
let _timeTo = document.getElementById("to");
let _timeFrom = document.getElementById("from");
let _descripton = document.getElementById("inputdescripton");

// When the user clicks the button, open the modal
if(btn) {
    btn.onclick = function() { 
        VSS.getService(VSS.ServiceIds.Dialog).then(function(dialogService) {
            var extensionCtx = VSS.getExtensionContext();
            // Build absolute contribution ID for dialogContent
            var contributionId = extensionCtx.publisherId + "." + extensionCtx.extensionId + ".registration-form";
            var registrationForm;

            var dialogOptions = {
                title: "Time Traker",
                width: 800,
                height: 600,
                okText: "Guardar e fechar",
                cancelText: "Cancelar",
                getDialogResult: function() {
                    // Get the result from registrationForm object
                    return registrationForm ? registrationForm.getFormData() : null;
                },
                //**********************
                //**** É AQUI QUE TENS DE CHAMAR A API *****
                //********************** 
                okCallback: function (result) {
                    // Log the result to the console
                    console.log(result);
                }
            };

            // dialogService.openDialog(contributionId, dialogOptions).then(function(dialog) {
            //     dialog.updateOkButton(true); 
            // });
            
            dialogService.openDialog(contributionId, dialogOptions).then(function(dialog) {
                // Get registrationForm instance which is registered in registrationFormContent.html
                dialog.getContributionInstance("registration-form").then(function (registrationFormInstance) {
                    // Keep a reference of registration form instance (to be used previously in dialog options)
                    registrationForm = registrationFormInstance;
                    
                    // Subscribe to form input changes and update the Ok enabled state
                    registrationForm.attachFormChanged(function(isValid) {~
                        dialog.updateOkButton(isValid);
                    });
                    
                    // Set the initial ok enabled state
                    registrationForm.isFormValid().then(function (isValid) {
                        dialog.updateOkButton(isValid);
                    });
                });                            
            });
        });
    }
}