let type = document.getElementById("type");
let date = document.getElementById("date");
let time = document.getElementById("time");
let buttons = document.getElementsByClassName("boxhour");
let timeTo = document.getElementById("to");
let timeFrom = document.getElementById("from");
let description = document.getElementById("inputdescription");

// Date object with the current date and time
let today = new Date();
date.valueAsDate = today;

// Set current time to the to input in the html
timeTo.value = today.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
// Set current time to the from input in the html
timeFrom.value = today.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

/////// Events ///////
buttons[0].onclick = function () {
    buttons[0].style.background = "rgb(73, 126, 191)"
    buttons[1].style.background = "rgb(34, 59, 89)"
    buttons[2].style.background = "rgb(34, 59, 89)"
    buttons[3].style.background = "rgb(34, 59, 89)"
    onDurationClick("00:30");
}

buttons[1].onclick = function () {
    buttons[1].style.background = "rgb(73, 126, 191)"
    buttons[0].style.background = "rgb(34, 59, 89)"
    buttons[2].style.background = "rgb(34, 59, 89)"
    buttons[3].style.background = "rgb(34, 59, 89)"
    onDurationClick("01:00")
}

buttons[2].onclick = function () {
    buttons[2].style.background = "rgb(73, 126, 191)"
    buttons[1].style.background = "rgb(34, 59, 89)"
    buttons[0].style.background = "rgb(34, 59, 89)"
    buttons[3].style.background = "rgb(34, 59, 89)"
    onDurationClick("02:00")
}

buttons[3].onclick = function () {
    buttons[3].style.background = "rgb(73, 126, 191)"
    buttons[1].style.background = "rgb(34, 59, 89)"
    buttons[2].style.background = "rgb(34, 59, 89)"
    buttons[0].style.background = "rgb(34, 59, 89)"
    onDurationClick("04:00")
}

// Event for when the to in the html is changed
timeTo.addEventListener('input', onChangeTimeTo);
// Event for when the from in the html is changed
timeFrom.addEventListener('input', onChangeTimeFrom);

/////// Fucntions ///////

// function onTypeChange() {
//     type = document.getElementById("type").value;
// }

function onDurationClick(interval) {
    time.value = interval;
    // Creates a new date with the value (day) from the date input
    let now = new Date(date.value);
    // Set the hours and minutes of the new date to the current time 
    now.setHours(new Date().getHours(), new Date().getMinutes());

    let toDate;

    // Create a new to date by adding the time from the button
    switch (interval) {
        case "00:30":
            toDate = new Date(now.getTime() + 30 * 60000);
            break;
        case "01:00":
            toDate = new Date(now.getTime() + 3600000);
            break;
        case "02:00":
            toDate = new Date(now.getTime() + 2 * 3600000);
            break;
        case "04:00":
            toDate = new Date(now.getTime() + 4 * 3600000);
            break;
    }

    // Set the to value in the html
    timeTo.value = String(toDate.getHours()).padStart(2, '0') + ':' + String(toDate.getMinutes()).padStart(2, '0');
    
    var event = new Event("change");
    timeTo.dispatchEvent(event);
}

function onChangeTimeTo(e) {
    // Create a new date object with the value from the date input to later set the hours and minutes
    let to = new Date(date.value);
    // Create a new date object with the value from the date input to later set the hours and minutes
    let from = new Date(date.value);

    // Get the hours from the to input hours to calculate the duration
    let toHours = Number(e.target.value.substring(0, 1) + e.target.value.substring(1, 2));
    // Get the minutes from the to input hours to calculate the duration
    let toMinutes = Number(e.target.value.substring(3, 4) + e.target.value.substring(4, 5));

    // Get the hours from the from input hours to calculate the duration
    let fromHours = Number(timeFrom.value.substring(0, 1) + timeFrom.value.substring(1, 2));
    // Get the minutes from the from input hours to calculate the duration
    let fromMinutes = Number(timeFrom.value.substring(3, 4) + timeFrom.value.substring(4, 5));

    // Set the hours and minutes to the selected date from the date input
    to.setHours(toHours, toMinutes);
    // Set the hours and minutes to the selected date from the date input
    from.setHours(fromHours, fromMinutes);

    // Time interval between from and to in millisecodns
    let duration = to - from;

    // Set the durantion in the html 
    time.value = msToTime(duration);

    // To style the boxhours buttons 
    setDefaultBoxHourStyle(duration);
}

function onChangeTimeFrom(e) {
    // Create a new date object with the value from the date input to later set the hours and minutes
    let to = new Date(date.value);
    // Create a new date object with the value from the date input to later set the hours and minutes
    let from = new Date(date.value);

    // Get the hours from the to input hours to calculate the duration
    let toHours = Number(timeTo.value.substring(0, 1) + timeTo.value.substring(1, 2));
    // Get the minutes from the to input hours to calculate the duration
    let toMinutes = Number(timeTo.value.substring(3, 4) + timeTo.value.substring(4, 5));

    // Get the hours from the from input hours to calculate the duration
    let fromHours = Number(e.target.value.substring(0, 1) + e.target.value.substring(1, 2));
    // Get the minutes from the from input hours to calculate the duration
    let fromMinutes = Number(e.target.value.substring(3, 4) + e.target.value.substring(4, 5));

    // Set the hours and minutes to the selected date from the date input
    to.setHours(toHours, toMinutes);
    // Set the hours and minutes to the selected date from the date input
    from.setHours(fromHours, fromMinutes);

    // Time interval between from and to in millisecodns
    let duration = to - from;

    // Set the durantion in the html 
    time.value = msToTime(duration);

    // To style the boxhours buttons
    setDefaultBoxHourStyle(duration)
}

// Convert milliseconds to format HH:MM
function msToTime(duration) {
    let minutes = Math.floor((duration / (1000 * 60)) % 60);
    let hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;

    return hours + ":" + minutes;
}

//If durantion is one of the boxhours set background and apply default background to all others
function setDefaultBoxHourStyle(duration) {
    switch (duration) {
        case 30 * 60000:
            buttons[0].style.background = "rgb(73, 126, 191)";
            buttons[1].style.background = "rgb(34, 59, 89)";
            buttons[2].style.background = "rgb(34, 59, 89)";
            buttons[3].style.background = "rgb(34, 59, 89)";
            break;
        case 3600000:
            buttons[0].style.background = "rgb(34, 59, 89)";
            buttons[1].style.background = "rgb(73, 126, 191)";
            buttons[2].style.background = "rgb(34, 59, 89)";
            buttons[3].style.background = "rgb(34, 59, 89)";
            break;
        case 2 * 3600000:
            buttons[0].style.background = "rgb(34, 59, 89)";
            buttons[1].style.background = "rgb(34, 59, 89)";
            buttons[2].style.background = "rgb(73, 126, 191)";
            buttons[3].style.background = "rgb(34, 59, 89)";
            break;
        case 4 * 3600000:
            buttons[0].style.background = "rgb(34, 59, 89)";
            buttons[1].style.background = "rgb(34, 59, 89)";
            buttons[2].style.background = "rgb(34, 59, 89)";
            buttons[3].style.background = "rgb(73, 126, 191)";
            break;
        default:
            buttons[0].style.background = "rgb(34, 59, 89)"
            buttons[1].style.background = "rgb(34, 59, 89)"
            buttons[2].style.background = "rgb(34, 59, 89)"
            buttons[3].style.background = "rgb(34, 59, 89)";
    }
}

document.addEventListener("DOMContentLoaded", function(event) { 
    VSS.init({
        usePlatformScripts: true,
        usePlatformStyles: true,
    });   
    
    var registrationForm = (function () {
        var callbacks = [];
    
        function inputChanged() {
            // Execute registered callbacks
            for (var i = 0; i < callbacks.length; i++) {
                callbacks[i](isValid());
            }
        }
    
        function isValid() {
            // Check whether form is valid or not
            return !!(type.value) && !!(date.value) && !!(time.value) && !!(timeTo.value) && !!(timeFrom.value) && !!(description.value);
        }
    
        function getFormData() {
            // Get form values
    
            return {
                type: type.value,
                date: date.value,
                time: time.value,
                timeTo: timeTo.value,
                timeFrom: timeFrom.value,
                description: description.value
            };
        }
    
        type.addEventListener("change", inputChanged);
        date.addEventListener("change", inputChanged);
        time.addEventListener("change", inputChanged);
        timeTo.addEventListener("change", inputChanged);
        timeFrom.addEventListener("change", inputChanged);
        description.addEventListener("keyup", inputChanged);
    
        return {
            isFormValid: function () {
                return isValid();
            },
            getFormData: function () {
                return getFormData();
            },
            attachFormChanged: function (cb) {
                callbacks.push(cb);
            }
        };
    })();
    // Register form object to be used across this extension
    VSS.register("registration-form", registrationForm);
});

